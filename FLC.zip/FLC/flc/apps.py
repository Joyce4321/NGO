from django.apps import AppConfig


class FlcConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'flc'
